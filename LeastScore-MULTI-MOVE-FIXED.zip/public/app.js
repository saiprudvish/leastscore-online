let token = localStorage.getItem("ls_token");
let socket = null;
let mode = "login";
let state = null;
let selectedIds = new Set();
let selectedSource = null;

const $ = id => document.getElementById(id);

function toast(msg) {
  const el = $("toast");
  if (!el) return;
  el.textContent = msg;
  el.className = "show";
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.className = "", 2600);
}

function show(which) {
  ["auth", "lobby", "game"].forEach(x => {
    const el = $(x);
    if (el) el.classList.toggle("hidden", x !== which);
  });
}

async function api(url, body) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const j = await r.json();
  if (!r.ok) throw Error(j.error || "Something went wrong.");
  return j;
}

async function enter() {
  try {
    const j = await api("/api/" + mode, {
      username: $("username").value,
      password: $("password").value
    });
    token = j.token;
    localStorage.setItem("ls_token", token);
    $("welcome").textContent = "Hi, " + j.username;
    show("lobby");
    connect();
  } catch (e) {
    $("authMsg").textContent = e.message;
  }
}

document.querySelectorAll(".tab").forEach(b => b.onclick = () => {
  document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
  b.classList.add("active");
  mode = b.dataset.mode;
  $("authBtn").textContent = mode === "login" ? "Enter the table" : "Create my account";
  $("authMsg").textContent = "";
});

$("authBtn").onclick = enter;
$("password").onkeydown = e => { if (e.key === "Enter") enter(); };
$("logout").onclick = () => {
  localStorage.removeItem("ls_token");
  if (socket) socket.disconnect();
  location.reload();
};

function connect() {
  if (!token) return;
  if (socket && socket.connected) return;
  socket = io({ auth: { token }, transports: ["websocket", "polling"] });

  socket.on("connect", () => toast("Connected to the table."));
  socket.on("connect_error", err => {
    console.error(err);
    toast("Game server connection failed. Refresh and try again.");
  });
  socket.on("disconnect", () => toast("Connection lost. Reconnecting…"));
  socket.on("errorMsg", msg => toast(msg));
  socket.on("state", s => {
    state = s;
    // Clear stale selections whenever the server advances the turn/state.
    if (state.turn !== state.me?.username || state.status !== "playing") {
      selectedIds.clear();
      selectedSource = null;
    }
    render();
  });
}

function requireSocket() {
  if (!socket || !socket.connected) {
    toast("Connecting to game server…");
    connect();
    return false;
  }
  return true;
}

$("create").onclick = () => {
  if (requireSocket()) socket.emit("createRoom");
};

$("playBots").onclick = () => {
  if (!requireSocket()) {
    setTimeout(() => {
      if (socket?.connected) startBots();
    }, 800);
    return;
  }
  startBots();
};

function startBots() {
  socket.emit("createRoom");
  const wait = setInterval(() => {
    if (state?.code) {
      clearInterval(wait);
      socket.emit("playBots", {
        code: state.code,
        count: Number($("botCount").value)
      });
    }
  }, 100);
  setTimeout(() => clearInterval(wait), 3000);
}

$("join").onclick = () => {
  if (!requireSocket()) return;
  const code = $("roomCode").value.trim().toUpperCase();
  if (!code) return toast("Enter the room code.");
  socket.emit("joinRoom", { code });
};

$("copyCode").onclick = () => {
  if (!state?.code) return;
  navigator.clipboard.writeText(state.code).then(() => toast("Room code copied."));
};

function cardHTML(c, i) {
  const selected = selectedIds.has(c.id) ? " selected" : "";
  return `<button class="card ${c.color || ""}${selected}" data-id="${c.id}" data-i="${i}"><div class="corner">${c.rank}<br><span class="suit">${c.suit}</span></div><div class="big">${c.suit}</div></button>`;
}

function rankValue(r) {
  return r === "A" ? 1 : r === "J" ? 11 : r === "Q" ? 12 : r === "K" ? 13 : Number(r);
}

function validLeavePreview(cards) {
  if (!cards.length) return true;
  if (cards.length % 2 === 0 && cards.every(c => c.rank === cards[0].rank)) return true;
  if (cards.length >= 3 && cards.length % 2 === 1) {
    const suit = cards[0].suit;
    if (!cards.every(c => c.suit === suit)) return false;
    const vals = cards.map(c => rankValue(c.rank)).sort((a, b) => a - b);
    if (new Set(vals).size !== vals.length) return false;
    if (vals.includes(1)) {
      if (vals[0] === 1 && vals[1] === 2) return vals.every((v, i) => i === 0 || v === vals[i - 1] + 1);
      return vals.length === 5 && vals.includes(10) && vals.includes(11) && vals.includes(12) && vals.includes(13) && vals.includes(1);
    }
    return vals.every((v, i) => i === 0 || v === vals[i - 1] + 1);
  }
  return false;
}

function updateMoveUI() {
  const myTurn = state?.status === "playing" && state?.turn === state?.me?.username;
  const move = $("move");
  const declare = $("declare");
  const deck = $("deck");
  const open = $("open");
  const count = selectedIds.size;

  if (move) {
    move.disabled = !myTurn || !selectedSource;
    move.textContent = selectedSource
      ? `Move → (${count} left)`
      : "Choose deck/open → Move";
  }
  if (declare) declare.disabled = !myTurn;
  if (deck) deck.classList.toggle("chosen", selectedSource === "deck");
  if (open) open.classList.toggle("chosen", selectedSource === "open");

  const status = $("handStatus");
  if (status && state?.me) {
    status.textContent = `${state.me.hand.length} cards${count ? ` • ${count} selected to leave` : ""}`;
  }
}

function render() {
  if (!state) return;
  show(state.status === "lobby" ? "lobby" : "game");
  $("code").textContent = state.code || "";
  $("round").textContent = "ROUND " + (state.round || 0);
  $("deckCount").textContent = state.deckCount ?? 0;
  $("myScore").textContent = state.me?.score ?? 0;

  if (state.status === "lobby") {
    $("welcome").textContent = "ROOM " + state.code;
    updateMoveUI();
    return;
  }

  const mine = state.turn === state.me?.username;
  $("turnBanner").textContent = state.status === "checking"
    ? `⚑ ${state.declaration.username} declared — checking scores…`
    : state.status === "roundOver"
      ? "Round complete — next round shortly"
      : state.status === "gameOver"
        ? "Game over"
        : mine ? "● Your turn — choose what to leave, then pick deck/open" : `● ${state.turn}'s turn`;
  $("turnBanner").style.color = mine ? "#e5b65a" : "#b6b7b2";

  $("openCard").innerHTML = state.openCard ? cardHTML(state.openCard, 0) : "";
  $("hand").innerHTML = (state.me?.hand || []).map(cardHTML).join("");

  document.querySelectorAll("#hand .card").forEach(el => {
    el.onclick = () => {
      if (!mine) return toast("Wait for your turn.");
      const id = el.dataset.id;
      if (selectedIds.has(id)) selectedIds.delete(id);
      else selectedIds.add(id);

      const cards = (state.me?.hand || []).filter(c => selectedIds.has(c.id));
      if (!validLeavePreview(cards) && cards.length) {
        selectedIds.delete(id);
        return toast("That selection is not a valid group to leave.");
      }
      render();
    };
  });

  $("players").innerHTML = state.players.map(p => {
    const action = p.lastAction
      ? p.lastAction.type === "move"
        ? `left ${p.lastAction.cards?.length || 0} • picked ${p.lastAction.from === "deck" ? "deck" : (p.lastAction.card?.rank || "") + (p.lastAction.card?.suit || "")}`
        : p.lastAction.type === "left"
          ? `left ${p.lastAction.cards.map(c => c.rank + c.suit).join(" ")}`
          : "waiting"
      : "waiting";
    return `<div class="player ${p.username === state.turn ? "active" : ""} ${p.eliminated ? "eliminated" : ""}"><div class="avatar">${p.username[0].toUpperCase()}</div><div class="pname">${p.username}${p.username === state.me?.username ? " (you)" : ""}${p.bot ? " 🤖" : ""}<br><small>${action}</small></div><div class="points">${p.score}</div>${p.username === state.turn ? '<i class="turn-dot"></i>' : ""}</div>`;
  }).join("");

  $("log").innerHTML = (state.log || []).map(x => `<div class="logline">${x.msg}</div>`).join("");

  if (state.status === "roundOver" || state.status === "gameOver") {
    const rows = (state.declaration?.summary || []).map(x => `<tr><td colspan="3"><b>${x.username}</b> · round ${x.roundScore} · total ${x.score}<br><small>Hand: ${(x.hand || []).map(c => c.rank + c.suit).join(" ")} · Left: ${(x.left || []).map(c => c.rank + c.suit).join(" ")} · Picked: ${(x.picked || []).map(c => c === "deck" ? "DECK" : c.rank + c.suit).join(" ")}</small></td></tr>`).join("");
    $("roundResult").classList.remove("hidden");
    $("roundResult").innerHTML = `<h3>${state.declaration.winner ? "Declaration wins" : "Declaration loses (+25)"}</h3><p>Declarer's remaining score: <b>${state.declaration.declarerScore}</b></p><table><tr><th>Round details</th></tr>${rows}</table>${state.status === "gameOver" ? '<p><b>🏆 Last player standing!</b></p>' : ""}`;
  } else {
    $("roundResult").classList.add("hidden");
  }

  updateMoveUI();
}

// Choose where the picked card will come from. Nothing is removed yet.
$("deck").onclick = () => {
  if (state?.turn !== state?.me?.username) return toast("Wait for your turn.");
  selectedSource = selectedSource === "deck" ? null : "deck";
  updateMoveUI();
};

$("open").onclick = () => {
  if (state?.turn !== state?.me?.username) return toast("Wait for your turn.");
  selectedSource = selectedSource === "open" ? null : "open";
  updateMoveUI();
};

$("move").onclick = () => {
  if (state?.turn !== state?.me?.username) return toast("Wait for your turn.");
  if (!selectedSource) return toast("Choose DECK or OPEN first.");

  const cards = (state.me?.hand || []).filter(c => selectedIds.has(c.id));
  if (!validLeavePreview(cards)) return toast("Select a valid group to leave: 2/4 same rank or 3/5/7… same-suit sequence.");

  socket.emit("move", {
    code: state.code,
    source: selectedSource,
    leaveIds: [...selectedIds]
  });

  selectedIds.clear();
  selectedSource = null;
};

$("declare").onclick = () => {
  if (state?.turn !== state?.me?.username) return toast("Wait for your turn.");
  socket.emit("declare", { code: state.code });
};

document.addEventListener("click", e => {
  if (e.target.id === "startGame") socket.emit("startGame", { code: state.code });
});

const oldRender = render;
render = function () {
  oldRender();
  if (state?.status === "lobby") {
    if (!$("lobby-wrap-start")) {
      const panel = document.createElement("div");
      panel.id = "lobby-wrap-start";
      panel.className = "panel";
      panel.style.marginTop = "16px";
      panel.innerHTML = '<h2>Room ready</h2><p>Share the code above. The host starts when everyone joins.</p><button id="startGame" class="primary">Start game</button>';
      document.querySelector(".lobby-wrap").appendChild(panel);
    }
  }
};

(async () => {
  if (!token) return show("auth");
  try {
    const r = await fetch("/api/me", { headers: { Authorization: "Bearer " + token } });
    if (!r.ok) {
      localStorage.removeItem("ls_token");
      token = null;
      return show("auth");
    }
    const j = await r.json();
    $("welcome").textContent = "Hi, " + j.username;
    show("lobby");
    connect();
  } catch {
    show("auth");
  }
})();
